# SCRIPT VPSPACK 5.8
#
# INSTALACION
#
apt-get update && apt-get upgrade -y; wget https://raw.githubusercontent.com/lacasitamx/vpspack5.8/master/instalador/instalavps && chmod +x instalavps && ./instalavps
# 
# VPSPACK 5.8
# REVENTADO X: ILLUMINATIS
# CREDITOS: PWRMX
# BY : TEAM ILUMINATIS
# TOTALMENTE FREE
